package com.example.myfood.abstracts.view;

import android.content.Context;

public interface BaseMvpView {
    Context getContext();
}
