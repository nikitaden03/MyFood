package com.example.myfood.components.login.backstage;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.example.myfood.R;
import com.example.myfood.abstracts.presenter.BasePresenter;
import com.example.myfood.components.login.ui.UiContract;

public class LoginPresenter extends BasePresenter implements LoginContract.Presenter, AsyncLoginCallBack {

    @Override
    public void onClickButton(int id) {
        switch (id) {
            case R.id.button_to_choose_fragment:
                ((LoginContract.View) view).showSignUpFirstFragment();
                break;
            case R.id.button_to_login_fragment:
                ((LoginContract.View) view).showLogInFragment();
                break;
            case  R.id.sign_up_back_arrow:
            case R.id.login_back_arrow:
                ((LoginContract.View) view).previousFragment();
                break;
            case R.id.sign_up_first_type:
                ((LoginContract.View) view).showSignUpFirstTypeFragment();
                break;
            case R.id.sign_up_second_type:
                ((LoginContract.View) view).showSignUpSecondTypeFragment();
                break;
            case R.id.sign_up_types_account_button:
                ((UiContract.Fragments.SignUpChooseAccount)((LoginContract.View) view).getFragmentNow()).showInformFragment();
        }
    }

    @Override
    public void login(String email, String password) {
        Log.d("MYTAG", "login in Presenter");
        UiContract.Fragments.LoginFragment fragment = (UiContract.Fragments.LoginFragment) ((LoginContract.View) view).getFragmentNow();
        fragment.hideAlerts();
        if (email.matches("\\s*") || password.matches("\\s*")) {
            if (email.matches("\\s*")) {
                fragment.showEmailAlert(view.getContext().getResources().getString(R.string.email_alert));
            }
//          Код для проверки валидности почты
            if (password.matches("\\s*")) {
                fragment.showPasswordAlert(view.getContext().getResources().getString(R.string.password_alert));
            }
            return;
        }

        AsyncLogin asyncLogin = new AsyncLogin(this);
        asyncLogin.execute();
    }

    @Override
    public void getAsyncTaskResult(Integer integer) {
        switch (integer) {
            case 200:
                Log.d("MYTAG", "200");
        }
    }

    class AsyncLogin extends AsyncTask<String, Void, Integer> {

        ProgressDialog progressDialog;
        AsyncLoginCallBack asyncLoginCallBack;

        AsyncLogin(AsyncLoginCallBack asyncLoginCallBack) {
            this.asyncLoginCallBack = asyncLoginCallBack;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.d("MYTAG", view.getContext().toString());
            progressDialog = new ProgressDialog(view);
            progressDialog.setTitle("Пожалуйста, подождите");
            progressDialog.setMessage("Ведется соединение с сервером!");
            progressDialog.show();
        }

        @Override
        protected Integer doInBackground(String... strings) {
            try {
//              Общение с БД
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return 200;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            progressDialog.dismiss();
            asyncLoginCallBack.getAsyncTaskResult(integer);
        }
    }
}

interface AsyncLoginCallBack {
    void getAsyncTaskResult(Integer integer);
}