package com.example.myfood.components.login.ui;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.myfood.R;
import com.example.myfood.abstracts.view.BaseCompatActivity;
import com.example.myfood.components.login.backstage.LoginContract;
import com.example.myfood.components.login.backstage.LoginPresenter;

public class LogInActivity extends BaseCompatActivity implements LoginContract.View, UiContract.View {

    LoginPresenter presenter;
    LoginFirstFragment fragment1;
    LogInSecondFragment fragment2;
    Fragment fragmentNow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        presenter = new LoginPresenter();
        presenter.attach(this);
        fragment1 = new LoginFirstFragment();
        replaceFragment(fragment1, false);
    }

    @Override
    public Context getContext() {
        return getApplicationContext();
    }

    @Override
    public void onClick(int id) {
        Log.d("MYTAG", "onClick in LogInActivity");
        presenter.onClickButton(id);
    }

    @Override
    public void onClickLogin(String email, String password) {
        presenter.login(email, password);
    }

    @Override
    public void showLogInFragment() {
        fragment2 = new LogInSecondFragment();
        replaceFragment(fragment2, true);
    }

    @Override
    public void showSignUpFirstFragment() {
        Fragment fragment3 = new SignUpFirstFragment();
        replaceFragment(fragment3, true);
    }

    @Override
    public void showSignUpFirstTypeFragment() {
        Log.d("MYTAG", "showSignUpFirstTypeFragment");
        Fragment fragment4 = new SignUpFirstTypeFragment();
        replaceFragment(fragment4, true);
    }

    @Override
    public void showSignUpSecondTypeFragment() {
        Log.d("MYTAG", "showSignUpSecondTypeFragment");
    }

    @Override
    public void previousFragment() {
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public Fragment getFragmentNow() {
        return fragmentNow;
    }

    @Override
    public void replaceFragment(Fragment fragmentAdd, boolean isAddBackStage) {
        Log.d("MYTAG", "Replace or add fragment");
        fragmentNow = fragmentAdd;
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.log_in_activity, fragmentAdd);
        if (isAddBackStage) fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

}
