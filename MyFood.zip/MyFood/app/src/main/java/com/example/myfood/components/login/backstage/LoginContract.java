package com.example.myfood.components.login.backstage;

import android.os.AsyncTask;

import androidx.fragment.app.Fragment;

import com.example.myfood.abstracts.presenter.BaseMvpPresenter;
import com.example.myfood.abstracts.view.BaseMvpView;

public interface LoginContract {
    interface Presenter extends BaseMvpPresenter {
        void onClickButton(int id);
        void login(String email, String password);
    }
    interface View extends BaseMvpView {
        void replaceFragment(Fragment fragmentAdd, boolean isAddBackStage);
        void previousFragment();
        void showLogInFragment();
        Fragment getFragmentNow();
        void showSignUpFirstTypeFragment();
        void showSignUpSecondTypeFragment();
        void showSignUpFirstFragment();
    }
}
